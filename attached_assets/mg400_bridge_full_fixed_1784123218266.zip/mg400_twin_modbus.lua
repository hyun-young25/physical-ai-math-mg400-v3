-- ============================================================
-- MG400 디지털 트윈 연동 스크립트 (Modbus TCP, 단방향 명령 수신)
-- DobotStudio Pro 스크립트 편집기에 붙여넣고 실행하세요.
--
-- 사용 전 확인:
--   1. 학교 PC에서 브리지 먼저 실행:
--      python -m mg400_bridge --modbus
--   2. 아래 BRIDGE_IP를 학교 PC의 실제 LAN IP로 변경
--      (Windows: ipconfig / Mac·Linux: ip addr)
--
-- 레지스터 맵 (브리지 → MG400, 단방향):
--   Coil 0   : 트리거  (브리지→1, Lua→0 완료 후 초기화)
--   HR 0     : 명령 코드
--                0 = 대기 (아무것도 안 함)
--                1 = MovJ  (HR 1~4 의 X/Y/Z/R 으로 이동)
--                2 = Home  (홈 자세로 이동)
--                3 = Enable  (서보 활성화)
--                4 = Disable (서보 비활성화)
--                5 = SuctionOn  (흡착 ON)
--                6 = SuctionOff (흡착 OFF)
--   HR 1     : X 목표 (×10, U16, 음수는 65536 보수, mm)
--   HR 2     : Y 목표 (×10, U16, mm)
--   HR 3     : Z 목표 (×10, U16, mm)
--   HR 4     : R 목표 (×10, U16, °)
-- ============================================================

local BRIDGE_IP   = "192.168.1.100"   -- ← 학교 PC IP로 변경!
local BRIDGE_PORT = 502
local SLAVE_ID    = 1
local MOVE_SPEED  = 50                -- 이동 속도 (1~100%)
local POLL_MS     = 50                -- 폴링 주기 (ms)
local SUCTION_DO  = 1                 -- 흡착 DO 포트 번호 (배선에 맞게 변경)

-- U16 → 실수 복원 (×10 스케일, 음수는 2의 보수)
local function restore(val)
    if val > 32767 then
        return (val - 65536) / 10.0
    else
        return val / 10.0
    end
end

-- [1단계] 브리지 Modbus TCP 서버에 연결
local err, modbus_id = ModbusCreate(BRIDGE_IP, BRIDGE_PORT, SLAVE_ID)

if err ~= 0 then
    print("연결 실패! 에러코드: " .. tostring(err))
    print("확인사항:")
    print("  - 브리지 PC에서 python -m mg400_bridge --modbus 실행 여부")
    print("  - BRIDGE_IP = " .. BRIDGE_IP .. " 가 맞는지 확인")
    print("  - 방화벽에서 TCP 502 포트 허용 여부")
else
    print("==============================================")
    print("  MG400 디지털 트윈 연동 시작!")
    print("  브리지: " .. BRIDGE_IP .. ":" .. BRIDGE_PORT)
    print("  지원 명령: MovJ / Home / Enable / Disable / Suction")
    print("==============================================")

    -- [2단계] 명령 폴링 루프
    while true do

        -- Coil 0 확인: 브리지가 1로 세팅하면 명령 실행
        local coil_data = GetCoils(modbus_id, 0, 1)

        if type(coil_data) == "table" and coil_data[1] == 1 then

            -- HR 0: 명령 코드 읽기
            local cmd_data = GetHoldRegs(modbus_id, 0, 1, "U16")

            if type(cmd_data) == "table" and cmd_data[1] ~= nil then
                local cmd = cmd_data[1]

                -- ── MovJ: HR 1~4 에서 목표 좌표 읽어 이동 ──────────────
                if cmd == 1 then
                    local coord = GetHoldRegs(modbus_id, 1, 4, "U16")
                    if type(coord) == "table" and coord[1] ~= nil then
                        local targetX = restore(coord[1])
                        local targetY = restore(coord[2])
                        local targetZ = restore(coord[3])
                        local targetR = restore(coord[4])
                        print(string.format(
                            "MovJ → X=%.1f  Y=%.1f  Z=%.1f  R=%.1f",
                            targetX, targetY, targetZ, targetR
                        ))
                        local p = {
                            coordinate = {targetX, targetY, targetZ, targetR},
                            tool = 0,
                            user = 0
                        }
                        local opt = {SpeedJ = MOVE_SPEED, AccJ = MOVE_SPEED}
                        MovJ(p, opt)
                        print("MovJ 완료")
                    else
                        print("MovJ: 좌표 읽기 실패")
                    end

                -- ── Home: 홈 자세로 이동 ────────────────────────────────
                elseif cmd == 2 then
                    print("Home 명령 수신")
                    Home()
                    print("Home 완료")

                -- ── Enable: 서보 활성화 ──────────────────────────────────
                elseif cmd == 3 then
                    print("Enable 명령 수신")
                    EnableRobot()
                    print("Enable 완료")

                -- ── Disable: 서보 비활성화 ──────────────────────────────
                elseif cmd == 4 then
                    print("Disable 명령 수신")
                    DisableRobot()
                    print("Disable 완료")

                -- ── SuctionOn: 흡착 ON ──────────────────────────────────
                elseif cmd == 5 then
                    print("Suction ON")
                    DO(SUCTION_DO, 1)

                -- ── SuctionOff: 흡착 OFF ────────────────────────────────
                elseif cmd == 6 then
                    print("Suction OFF")
                    DO(SUCTION_DO, 0)

                else
                    print("알 수 없는 명령 코드: " .. tostring(cmd))
                end

            else
                print("HR 읽기 실패 — 명령 코드 없음")
            end

            -- [완료 신호] Coil 0 → 0 으로 초기화
            SetCoils(modbus_id, 0, 1, {0})

        end

        Sleep(POLL_MS)
    end
end
